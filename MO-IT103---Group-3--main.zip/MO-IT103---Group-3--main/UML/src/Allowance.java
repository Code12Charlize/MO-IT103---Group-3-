public class Allowance {
    float riceSubsidy;
    float phoneAllowance;
    float clothingAllowance;

    public void calculateSalaryDeduction(){

    }

    public void updateSalaryDeductions(){
        
    }
}

