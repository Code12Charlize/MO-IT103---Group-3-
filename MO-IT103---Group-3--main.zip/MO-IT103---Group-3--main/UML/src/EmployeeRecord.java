
public class EmployeeRecord {
    
    public void main(){

      String attendance;
      float hourlyRate;
      float workingHours;
    }

    
    
}
