public class Department {
    String departmentName = ("Accounting");
    String employeeList = ("1. Charlize Bactong"); 
    
    private static void getDetails(){

    }
}
