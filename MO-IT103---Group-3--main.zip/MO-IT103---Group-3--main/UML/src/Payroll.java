public class Payroll {
    
    public void generatePayslip(){

    }

    public void calculateNetSalary(){
        
    }
}
