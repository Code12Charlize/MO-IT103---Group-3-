public class SalaryDeduction {
    float sssRate;
    float philHealthrate;
    float pagIbigRate;
    float withHoldingTaxRate;


    public void calculateSalaryDeduction(){

    }

    public void updateSalaryDeductions(){
        
    }
}
