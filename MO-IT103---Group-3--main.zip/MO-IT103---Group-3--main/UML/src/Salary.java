public class Salary {
        int id;
        String details;
        String calculation;


    public void calculateSalary(){

    }

    public void updateSalary(){
        
    }


        
    
}
