public class Main {
    
    String companyName = ("MotorPH");
    int numberOfEmployees = (39);
    String payrollPeriod = ("29 days");

    

    public static void searchEmployee () {

    }
    
    public static void payrollCalculator () {

    }
       
        
   
}
