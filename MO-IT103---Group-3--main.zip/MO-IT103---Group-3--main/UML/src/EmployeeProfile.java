public class EmployeeProfile {


    public void employeeProfile(){
        int employeeNumber;
        String employeeLastName;
        String employeeFirstName;
        String birthday;
        String address;
        int contactNumber;
        int SSSNumber;
        int philHealthNumber;
        int tinNumber;
        int pagIbigNumber;
        String status;
        String position;
        String immediateSupervisor;
        
    }
    
}
